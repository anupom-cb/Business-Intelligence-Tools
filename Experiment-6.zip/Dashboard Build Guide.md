# Dashboard Build Guide

## Page title

Global Superstore Executive Dashboard

## Filters

Add slicers for Region, Category, and Order Date using the Year hierarchy.

## KPI cards

Add cards for Total Sales, Total Profit, Total Orders, and Profit Margin.

## Charts

1. Clustered bar chart: Region on axis and Total Sales as value. Sort descending.
2. Column chart: Category on axis and Total Sales as value.
3. Line chart: Order Date by Month on axis and Total Sales as value.
4. Bar chart: Customer Name on axis and Total Sales as value. Apply a Top N filter of 10 by Total Sales.
5. Bar chart: Segment on axis and Total Profit as value.
6. Matrix scorecard: Sales, Profit, and Orders with their target, actual, variance, and status measures.

## Scorecard formatting

Apply conditional formatting to each Status field:

- Achieved: green
- Partially Achieved: amber
- Not Achieved: red

## Check values

With no slicers selected, the cards should return Total Sales of $12,642,501.91, Total Profit of $1,467,457.29, Total Orders of 25,728, and Profit Margin of 11.61%.
