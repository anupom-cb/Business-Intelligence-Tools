# Global Superstore Power BI Starter Kit

This kit supports Experiment 6: Dashboard and Scorecard Development Using Microsoft Power BI.

## Contents

- `Global Superstore 2018.xlsx` — source dataset with Orders, Returns, and People tables.
- `DAX Measures.txt` — copy-ready measures for Power BI.
- `Dashboard Build Guide.md` — steps to import, model, and build the report.
- `Experiment 6 Power BI Dashboard and Scorecard.docx` — completed experiment report and findings.

## How to create the Power BI report

1. Open Power BI Desktop and select **Get data > Excel**.
2. Select `Global Superstore 2018.xlsx`, then load Orders, Returns, and People.
3. Confirm data types: Order Date and Ship Date as Date; Sales, Quantity, Discount, Profit, and Shipping Cost as numeric.
4. Create relationships between Orders and Returns using Order ID, and between People and Orders using Region when required.
5. Create the measures from `DAX Measures.txt`.
6. Build the visuals listed in `Dashboard Build Guide.md`.
7. Save the finished report as `Global Superstore Executive Dashboard.pbix`.

The workbook holds the complete data. The report document contains independently calculated benchmark values for checking the Power BI results.
