# Global Superstore – Power BI Executive Dashboard & Scorecard (Experiment 6)

**Aim:** Executive dashboard + target-vs-actual business scorecard for Global Superstore.

## Folder map
| Folder | Contents |
|---|---|
| `01_Data` | `Global_Superstore_PowerBI_Data.xlsx` – cleaned star-schema data: Orders (51,290 rows), Dim_Region, Dim_Date, Dim_Year, Targets, Returns |
| `02_PowerQuery_M` | Power Query (M) scripts for each table |
| `03_DAX` | 40 ready-to-paste DAX measures (KPIs, YoY, targets, status, colours, best/worst) |
| `04_Theme` | Custom Power BI theme (import via View > Themes) |
| `05_Dashboard_Design` | Wireframe (Part A) and full-colour dashboard preview |
| `06_Analysis` | Findings, recommendation, supporting tables |
| `07_Documentation` | Step-by-step BUILD_GUIDE.md mapped to Steps 1–16 of the experiment |

## Quick start
1. Read `07_Documentation/BUILD_GUIDE.md`.
2. Load `01_Data` workbook → create relationships → paste DAX → import theme → build visuals.
3. Compare with `05_Dashboard_Design/Dashboard_Preview.png`.

**Dataset used:** Global Superstore 2018 (your three uploaded copies were identical; `Employee_DB.xlsx` was not relevant and is not used).
**Note:** a `.pbix` can only be created inside Power BI Desktop, so this package gives you everything to build it quickly rather than a pre-built file.

## ▶ Open directly in Power BI Desktop (PBIP project)
1. Unzip the folder fully.
2. Double-click `1_SET_DATA_PATH.bat` (once) – points the model to `01_Data\Global_Superstore_PowerBI_Data.xlsx` on your PC.
3. Double-click `Global_Superstore_Dashboard.pbip`, then **Home > Refresh** to load data.
See `OPEN_IN_POWER_BI.txt` for troubleshooting. The PBIP contains the data model (6 tables, 5 relationships, 40 measures) and a one-page report (4 KPI cards, 5 charts, 3 slicers, scorecard matrix).
If it does not open, follow `07_Documentation/BUILD_GUIDE.md` instead.
