# Business Analysis – Findings & Recommendation (Steps 14–16)
Source: Global Superstore (Orders 2014–2017, 51,290 lines, 25,728 orders, 17,415 customers). Figures computed directly from the project data.

## Headline KPIs (all years)
| Metric | Value |
|---|---|
| Total Sales | $12.64M |
| Total Profit | $1.47M |
| Total Orders | 25,728 |
| Profit Margin | 11.6% |

Sales grew every year: +18.5% (2015), +27.2% (2016), +26.3% (2017); profit rose from $249K (2014) to $504K (2017).

## Required answers
| Question | Answer | Evidence |
|---|---|---|
| **Best performing region** | **Western Europe** | Highest sales ($1.73M) and highest profit ($218K) |
| **Worst performing region** | **Western Asia** (by profit; Central Asia has the worst margin) | Profit −$53.9K on $317K sales; Western Africa −$50.4K; Central Asia margin −37.7% |
| **Most profitable category** | **Technology** | $664K profit, 14.0% margin, also largest sales ($4.74M) |
| **Least profitable category** | **Furniture** | $285K profit, only 6.9% margin; Tables sub-category loses $64K |

Other observations
- Segment: Consumer generates 51% of profit ($749K), Corporate $441K, Home Office $277K.
- 3 regions are loss-making overall (Western Asia, Western Africa, Central Asia).
- Order lines with discount > 30% total **−$794K profit** on $1.55M sales, while the rest earn +$2.26M.
- FY2017 scorecard (region level): Sales 17 Achieved / 6 Partial; Orders 20 / 3; Profit 13 Achieved / 3 Partial / 7 Not Achieved – profit is the weakest KPI.

## Recommendation (one)
**Cap discounts at 30% (require approval above it) and reprice/discontinue loss-making Furniture lines such as Tables, starting in Western Asia, Western Africa and Central Asia.** Deep discounting on low-margin items is the main driver of lost profit: lines discounted above 30% lose ~$0.8M, which is more than half of the company's $1.47M profit. Redirecting effort to Technology and Western Europe, where margin is highest, while fixing these leaks should lift margin well above 11.6% without needing more sales volume.

## Notes
- Scorecard targets are planning assumptions (see BUILD_GUIDE.md) – replace with official targets if your instructor provides them.
- `Analysis_Tables.xlsx` has the supporting tables (region, category, sub-category, segment, market, year, and region-year scorecard with status).
