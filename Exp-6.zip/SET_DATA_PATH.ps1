$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$tmdl = Join-Path $root "Global_Superstore_Dashboard.SemanticModel\definition\expressions.tmdl"
$data = Join-Path $root "01_Data\Global_Superstore_PowerBI_Data.xlsx"
$text = [System.IO.File]::ReadAllText($tmdl)
$text = [regex]::Replace($text, 'expression FilePath = "[^"]*"', ('expression FilePath = "' + $data + '"'))
[System.IO.File]::WriteAllText($tmdl, $text, (New-Object System.Text.UTF8Encoding($false)))
Write-Host "Data path set to: $data"
