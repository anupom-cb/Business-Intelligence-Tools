# Build Guide – Power BI Executive Dashboard & Scorecard (Experiment 6)

Estimated time: 30–40 minutes in Power BI Desktop. Everything you need is in this project folder.

## Part A – Planning (Steps 1–4)
| Step | What to do |
|---|---|
| 1 | Open Power BI Desktop → new blank report → **File > Save as** `Global_Superstore_Dashboard.pbix`. |
| 2 | Management metrics: Sales, Profit, Orders, Profit Margin %, target attainment, regional / category / segment / customer performance, monthly trend. |
| 3 | Visual choices: **Card** (KPIs), **Bar** (region, customers – long labels), **Donut** (category share, only 3 slices), **Column** (segment), **Line** (time trend), **Matrix** (scorecard). |
| 4 | Layout sketch = `05_Dashboard_Design/Dashboard_Wireframe.png`. Target look = `Dashboard_Preview.png`. |

## Load the data
1. **Home > Transform data > Manage parameters > New**: `FilePath` (Text) = full path of `01_Data/Global_Superstore_PowerBI_Data.xlsx`.
2. For each query in `02_PowerQuery_M/queries.pq`: **New Source > Blank Query > Advanced Editor**, paste, rename to the name in the comment (`Orders`, `Dim_Region`, `Dim_Date`, `Dim_Year`, `Targets`).
   *(Shortcut: Get Data > Excel > tick Orders, Dim_Region, Dim_Date, Dim_Year, Targets > Load. The M scripts just add typing/cleaning.)*
3. **Close & Apply**.

## Model (Model view)
Create these **Many-to-One, single-direction** relationships (drag field to field):

| From (many) | To (one) |
|---|---|
| Orders[Order Date] | Dim_Date[Date] |
| Orders[Region] | Dim_Region[Region] |
| Targets[Region] | Dim_Region[Region] |
| Targets[Year] | Dim_Year[Year] |
| Dim_Date[Year] | Dim_Year[Year] |

Then: select **Dim_Date → Table tools → Mark as date table → Date**. Hide `Orders[Region]`, `Targets[Region]`, `Targets[Year]`, `Dim_Date[Year]`; use the dimension columns in visuals/slicers.
Sort `Dim_Date[Month]` by `Month Number`.

## Measures
**Home > Enter data** → create an empty table `_Measures`. Paste every measure from `03_DAX/measures.dax` (Modeling > New measure).
Format: Total Sales/Profit → Currency $ 0 dp; Profit Margin % & Achievement % → Percentage 1 dp.

## Theme
**View > Themes > Browse for themes** → `04_Theme/GlobalSuperstore_Theme.json`. Page background → `#F3F6FA`, canvas 16:9 (default 1280×720).

## Part B – KPI dashboard (Steps 5–7)
| Visual | Type | Fields |
|---|---|---|
| Total Sales | Card | `[Total Sales]` |
| Total Profit | Card | `[Total Profit]` |
| Total Orders | Card | `[Total Orders]` |
| Profit Margin % | Card | `[Profit Margin %]` |
| Sales by Region | Clustered bar | Y: `Dim_Region[Region]`; X: `[Total Sales]`; Filters: **Top N 10 by Total Sales** (optional) |
| Sales by Category | Donut | Legend: `Orders[Category]`; Values: `[Total Sales]` |
| Monthly Sales Trend | Line | X: `Dim_Date[Year-Month]` (or Year > Month hierarchy); Y: `[Total Sales]` |
| Top 10 Customers | Clustered bar | Y: `Orders[Customer Name]`; X: `[Total Sales]`; Filter pane → Customer Name → **Top N = 10 by [Total Sales]** |
| Profit by Segment | Clustered column | X: `Orders[Segment]`; Y: `[Total Profit]` |

Formatting (Step 7): one font family (Segoe UI), titles on and left-aligned, data labels on, gridlines light, consistent colours from theme, align/distribute visuals (Format > Align), card callout 28 pt.
Optional: card colour using `[Margin Color]` (Format > Callout value > fx > Field value).

## Part C – Interactivity (Steps 8–10)
1. Add 3 **Slicers**: `Dim_Year[Year]` (Tile), `Dim_Region[Region]` (Dropdown), `Orders[Category]` (Dropdown).
2. **Format > Edit interactions**: confirm all visuals + scorecard respond to each slicer.
3. Test: select 2017 → KPIs change; select Region = Western Europe; Category = Technology; Ctrl+click for multi-select; use *Clear all slicers* (add a Bookmark button, optional).
4. Optional polish: Sync slicers, tooltips, drill-through page on Region.

## Part D – Scorecard (Steps 11–13)
1. Insert a **Matrix** (or Table): Rows = `Dim_Region[Market]` → `Dim_Region[Region]` (hierarchy).
2. Values (in this order): `[Total Sales]`, `[Sales Target]`, `[Sales Achievement %]`, `[Sales Indicator]`, `[Total Profit]`, `[Profit Target]`, `[Profit Achievement %]`, `[Profit Indicator]`, `[Total Orders]`, `[Order Target]`, `[Order Achievement %]`, `[Order Indicator]`.
3. **Conditional formatting** → each Indicator column: *Format > Cell elements > Font colour > fx > Format style: Field value > `[Sales Status Color]`* (use Profit/Order colour measures for their own columns).
4. Rules: **Achieved ≥ 100%** (green) · **Partially Achieved 80–99.9%** (amber) · **Not Achieved < 80%** (red).
5. Add KPI visuals (optional): Value = `[Total Sales]`, Target = `[Sales Target]`.
6. Select Year = 2017 for the headline scorecard (targets exist for 2014–2017).

> **Targets** are a planning assumption: FY target = prior-year actual × 1.15 for each Region (loss-making regions: target = 15% smaller loss). 2014 uses a seeded ±10% baseline because no earlier year exists. Replace with real targets in `Targets` sheet and refresh.

## Part E – Analysis (Steps 14–16)
Add a text/Card strip with `[Best Region]`, `[Worst Region]`, `[Most Profitable Category]`, `[Least Profitable Category]`, then write your finding. Ready-made answers are in `06_Analysis/FINDINGS_AND_RECOMMENDATION.md`.

## Final checks
- [ ] All 4 KPI cards, 5 charts, 3 slicers, scorecard present on ONE page
- [ ] Slicers filter every visual
- [ ] Scorecard shows 3 status colours
- [ ] Page name: "Executive Dashboard" · File saved as .pbix · Export PDF (File > Export) for submission
