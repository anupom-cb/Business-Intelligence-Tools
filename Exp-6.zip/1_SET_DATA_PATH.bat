@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0SET_DATA_PATH.ps1"
pause
