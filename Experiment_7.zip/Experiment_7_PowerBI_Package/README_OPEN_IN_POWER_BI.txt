EXPERIMENT 7 — POWER BI PACKAGE
================================

Files
-----
data/Orders_PowerBI.csv       Cleaned/import-friendly order-line data with date helper columns
data/Returns.csv              Returns table from the supplied workbook
data/People.csv               Regional manager table from the supplied workbook
data/Global_Superstore_Analysis.xlsx  Prepared workbook with source tables and summary tabs
powerbi/DAX_Measures.txt      Measures and modeling guidance
powerbi/Power_Query_M_Starter.txt  Optional Power Query type-cleaning starter
Experiment_7_Business_Insight_Report.docx  Full experiment report
Experiment_7_Executive_Presentation.pptx  6-slide presentation
Recommendation_Summary.csv   Action summary
charts/                       Charts used in the report and presentation

Open in Microsoft Power BI Desktop
-----------------------------------
1. Extract this ZIP to a normal folder.
2. Open Power BI Desktop.
3. Home > Get data > Text/CSV; select data/Orders_PowerBI.csv. Choose Transform Data to inspect types, then Close & Apply.
   You may instead choose Get data > Excel and select data/Global_Superstore_Analysis.xlsx.
4. If importing separate CSVs, import Returns.csv and People.csv as additional tables.
5. In Model view, create a Calendar table and relate Calendar[Date] (one) to Orders[Order Date] (many).
6. IMPORTANT: Orders has multiple rows per Order ID. Do not directly create an ambiguous many-to-many relationship with Returns. For return-rate measures, create a distinct Order dimension (unique Order ID) and relate it to Orders and Returns.
7. Open powerbi/DAX_Measures.txt and create the measures in Power BI using Modeling > New measure. If using the optional Calendar DAX, create it using Modeling > New table and add the date columns as separate calculated columns.
8. Suggested report page:
   - KPI cards: Total Sales, Total Profit, Profit Margin %, Distinct Orders
   - Line chart: Sales and Profit by Order Date (month)
   - Bar chart: Sales by Region
   - Bar chart: Profit by Sub-Category
   - Clustered column chart: Sales and Profit by Category
   - Slicers: Order Year, Region, Market, Category, Segment, Ship Mode
9. Add a second page for negative-profit products and a third for segment/returns/shipping analysis.
10. Save the finished report from Power BI Desktop as Experiment_7_Global_Superstore.pbix.

Important
---------
A native .pbix file cannot be authored or validated outside Power BI Desktop in this environment. This ZIP contains Power BI-ready data, DAX, model guidance, charts, the completed written experiment and slides so you can import the data and save a real .pbix in the Power BI application. Do not submit this package as if it already contains a .pbix.
Dataset statistics calculated from the supplied workbook:
- Rows: 51,290; distinct Order IDs: 25,728; dates: 2014-01-01 to 2017-12-31
- Sales: $12,642,501.91; Profit: $1,467,457.29; Profit margin: 11.61%
- Annual sales growth from 2014 to 2017: 90.3%
